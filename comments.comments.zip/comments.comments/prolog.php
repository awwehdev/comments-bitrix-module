<?
define("ADMIN_MODULE_NAME", "comments.comments");
?>
