# Download

http://localhost/bitrix/admin/partner_modules.php