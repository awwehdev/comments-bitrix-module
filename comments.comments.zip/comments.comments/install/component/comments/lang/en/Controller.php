<?php
$MESS["COMMENT_CREATE_ERROR"] = "An error occurred while creating the record";
$MESS["COMMENT_FIELD_NAME_REQUIRED"] = "Enter name";
$MESS["COMMENT_FIELD_EMAIL_REQUIRED"] = "Enter E-mail";
$MESS["COMMENT_FIELD_TEXT_REQUIRED"] = "Enter comment";
$MESS["COMMENT_FIELD_EMAIL_INVALID"] = "E-mail is not valid";
$MESS["COMMENT_CREATED"] = "Your comment has been added";
