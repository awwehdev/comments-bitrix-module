<?php
$MESS["COMMENT_CREATE_ERROR"] = "При создании комментария произошла ошибка";
$MESS["COMMENT_FIELD_NAME_REQUIRED"] = "Введите имя";
$MESS["COMMENT_FIELD_EMAIL_REQUIRED"] = "Введите E-mail";
$MESS["COMMENT_FIELD_TEXT_REQUIRED"] = "Введите комментарий";
$MESS["COMMENT_FIELD_EMAIL_INVALID"] = "E-mail не валидный";
$MESS["COMMENT_CREATED"] = "Ваш комментарий добавлен";