<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS["СOMMENTS_COMPONENT_PATH_ID"] = "local";
$MESS["СOMMENTS_COMPONENT_CHILD_PATH_ID"] = "childpath";
$MESS["СOMMENTS_COMPONENT_PATH_NAME"] = "Мои компоненты";
$MESS["СOMMENTS"] = "Comments";
$MESS["СOMMENTS_COMPONENT"] = "comments";
$MESS["СOMMENTS_COMPONENT_DESCRIPTION"] = "Comments";