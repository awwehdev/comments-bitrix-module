<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS["EXAMPLE_COMPSIMPLE_PROP_SETTINGS"] = "Выбор инфоблока и разделов";
$MESS["EXAMPLE_COMPSIMPLE_PROP_IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["EXAMPLE_COMPSIMPLE_PROP_IBLOCK_ID"] = "Инфоблок";
$MESS["EXAMPLE_COMPSIMPLE_PROP_SECTION_IDS"] = "ID разделов через запятую";