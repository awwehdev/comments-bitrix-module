<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
{
    die();
}

?>


<div id="app"></div>

<script src="/bitrix/components/comments/comments/templates/.default/comments.js"></script>
