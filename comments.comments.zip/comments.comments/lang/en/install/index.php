<?
$MESS["MODULE_COMMENTS_NAME"] = "Module comments";
$MESS["MODULE_COMMENTS_DESCRIPTION"] = "Module comments";
