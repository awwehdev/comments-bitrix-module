<?
$MESS["MODULE_COMMENTS_NAME"] = "Модуль comments";
$MESS["MODULE_COMMENTS_DESCRIPTION"] = "Модуль комментариев comments";
